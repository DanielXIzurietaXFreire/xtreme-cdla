// =====================================================
// CONSTANTES Y VARIABLES GLOBALES
// =====================================================
const STORAGE_KEY = 'xtremeGymClientes';
let clientes = [];
let clienteEnEdicion = null;

// =====================================================
// INICIALIZACIÓN
// =====================================================
function initApp() {
  cargarClientes();
  inicializarEventos();
  renderizarTablaClientes();
}

// =====================================================
// FUNCIONES DE ALMACENAMIENTO (localStorage)
// =====================================================
function cargarClientes() {
  const data = localStorage.getItem(STORAGE_KEY);
  clientes = data ? JSON.parse(data) : [];
}

function guardarClientes() {
  localStorage.setItem(STORAGE_KEY, JSON.stringify(clientes));
}

function obtenerClientePorId(id) {
  return clientes.find((c) => c.id === id);
}

function obtenerClientePorCedula(cedula) {
  return clientes.find((c) => c.cedula === cedula);
}

// =====================================================
// LOGIN Y DASHBOARD
// =====================================================
function simulateLogin() {
  showDashboard();
}

function loginSubmit(e) {
  e.preventDefault();
  showDashboard();
  return false;
}

function showDashboard() {
  document.getElementById('login-screen').classList.remove('active');
  document.getElementById('dashboard-screen').classList.add('active');
  document.getElementById('sidebar').classList.remove('sidebar-hidden');
  document.getElementById('tab-register').checked = true;
  updateSections();
}

// =====================================================
// CONTROL DE PESTAÑAS
// =====================================================
function inicializarEventos() {
  const tabRegister = document.getElementById('tab-register');
  const tabClients = document.getElementById('tab-clients');

  if (tabRegister) tabRegister.addEventListener('change', updateSections);
  if (tabClients) tabClients.addEventListener('change', updateSections);
}

function updateSections() {
  const sections = document.querySelectorAll('.section');
  const navItems = document.querySelectorAll('.nav-item');

  sections.forEach((s) => s.classList.remove('active'));
  navItems.forEach((n) => n.classList.remove('active'));

  if (document.getElementById('tab-register').checked) {
    const secRegister = document.getElementById('sec-register');
    if (secRegister) secRegister.classList.add('active');
    const labelRegister = document.querySelector('label[for="tab-register"]');
    if (labelRegister) labelRegister.classList.add('active');
  } else if (document.getElementById('tab-clients').checked) {
    const secClients = document.getElementById('sec-clients');
    if (secClients) secClients.classList.add('active');
    const labelClients = document.querySelector('label[for="tab-clients"]');
    if (labelClients) labelClients.classList.add('active');
    renderizarTablaClientes();
  }
}

// =====================================================
// REGISTRO DE CLIENTE
// =====================================================
async function registrarCliente(e) {
  if (e) e.preventDefault();

  const nombre = document.getElementById('nombre').value.trim();
  const cedula = document.getElementById('cedula').value.trim();
  const celular = document.getElementById('celular').value.trim();
  const fechaPago = document.getElementById('fecha-pago').value;
  const tipoPago = document.getElementById('tipo-pago').value;

  if (!nombre) {
    mostrarToast('Por favor completa el nombre completo', 'error');
    return false;
  }
  if (!cedula) {
    mostrarToast('Por favor completa la cédula', 'error');
    return false;
  }
  if (obtenerClientePorCedula(cedula)) {
    mostrarToast('La cédula ya está registrada en el sistema', 'error');
    return false;
  }
  if (!celular) {
    mostrarToast('Por favor completa el celular', 'error');
    return false;
  }
  if (!fechaPago) {
    mostrarToast('Por favor selecciona una fecha de pago', 'error');
    return false;
  }

  const fileInput = document.querySelector(
    '#sec-register .photo-capture[data-context="register"] .photo-file-input'
  );
  const file = fileInput && fileInput.files && fileInput.files[0] ? fileInput.files[0] : null;

  let fotoRostro = '';
  if (file) {
    try {
      fotoRostro = await leerArchivoComoDataURL(file);
    } catch (err) {
      mostrarToast('No se pudo leer la fotografía. Intenta nuevamente.', 'error');
      return false;
    }
  }

  const nuevoCliente = {
    id: Date.now(),
    nombre: nombre,
    cedula: cedula,
    celular: celular,
    fotoRostro: fotoRostro,
    fechaRegistro: obtenerFechaActual(),
    tipoPago: tipoPago,
    fechaPago: fechaPago,
    vencimiento: calcularVencimiento(fechaPago, tipoPago),
  };

  clientes.push(nuevoCliente);
  guardarClientes();

  limpiarFormularioRegistro();

  mostrarToast('Cliente registrado exitosamente ✓', 'success');
  renderizarTablaClientes();

  return false;
}

function limpiarFormularioRegistro() {
  const form = document.getElementById('form-register');
  if (form) form.reset();
}

// =====================================================
// EDICIÓN DE CLIENTE
// =====================================================
function abrirEditModal(clienteId) {
  clienteEnEdicion = obtenerClientePorId(clienteId);
  if (!clienteEnEdicion) return;

  document.getElementById('edit-nombre').value = clienteEnEdicion.nombre;
  document.getElementById('edit-cedula').value = clienteEnEdicion.cedula;
  document.getElementById('edit-celular').value = clienteEnEdicion.celular;
  document.getElementById('edit-fecha-registro').value = clienteEnEdicion.fechaRegistro;
  document.getElementById('edit-tipo-pago').value = clienteEnEdicion.tipoPago;
  document.getElementById('edit-fecha-pago').value = clienteEnEdicion.fechaPago;

  document.getElementById('edit-modal').style.display = 'flex';
}

function closeEditModal() {
  document.getElementById('edit-modal').style.display = 'none';
  clienteEnEdicion = null;
}

function saveClientEdit(e) {
  e.preventDefault();
  if (!clienteEnEdicion) return;

  const nombre = document.getElementById('edit-nombre').value.trim();
  const celular = document.getElementById('edit-celular').value.trim();
  const tipoPago = document.getElementById('edit-tipo-pago').value;
  const fechaPago = document.getElementById('edit-fecha-pago').value;

  if (!nombre || !celular || !tipoPago || !fechaPago) {
    mostrarToast('Todos los campos son obligatorios', 'error');
    return;
  }

  const cliente = obtenerClientePorId(clienteEnEdicion.id);
  if (cliente) {
    cliente.nombre = nombre;
    cliente.celular = celular;
    cliente.tipoPago = tipoPago;
    cliente.fechaPago = fechaPago;
    cliente.vencimiento = calcularVencimiento(fechaPago, tipoPago);

    guardarClientes();
    renderizarTablaClientes();
    closeEditModal();
    mostrarToast('Cliente actualizado exitosamente ✓', 'success');
  }
}

// =====================================================
// ELIMINAR CLIENTE (MODAL CONFIRMACIÓN)
// =====================================================
let clienteAEliminar = null;

function abrirModalEliminar(clienteId) {
  clienteAEliminar = obtenerClientePorId(clienteId);
  if (!clienteAEliminar) return;

  const elNombre = document.getElementById('eliminarNombre');
  const elCedula = document.getElementById('eliminarCedula');
  if (elNombre) elNombre.textContent = clienteAEliminar.nombre;
  if (elCedula) elCedula.textContent = clienteAEliminar.cedula;

  const fotoImg = document.getElementById('eliminarFoto');
  const fallbackIcon = document.getElementById('eliminarFotoIcon');
  if (fotoImg) {
    fotoImg.src = clienteAEliminar.fotoRostro || '';
    fotoImg.style.display = clienteAEliminar.fotoRostro ? 'block' : 'none';
  }
  if (fallbackIcon) {
    fallbackIcon.style.display = clienteAEliminar.fotoRostro ? 'none' : 'inline-flex';
  }

  const modal = document.getElementById('modalEliminar');
  if (modal) modal.style.display = 'flex';
}

function cerrarModalEliminar() {
  const modal = document.getElementById('modalEliminar');
  if (modal) modal.style.display = 'none';
  clienteAEliminar = null;
}

function eliminarClienteConfirmado() {
  if (!clienteAEliminar) return;

  clientes = clientes.filter((c) => c.id !== clienteAEliminar.id);
  guardarClientes();
  renderizarTablaClientes();
  cerrarModalEliminar();
  mostrarToast('Cliente eliminado correctamente', 'success');
}


// =====================================================
// RENDERIZAR TABLA DE CLIENTES
// =====================================================
let clienteDetalle = null;

function obtenerDiasRestantesDesdeVencimiento(vencimiento) {
  if (!vencimiento) return null;
  const fechaVenc = new Date(vencimiento);
  if (Number.isNaN(fechaVenc.getTime())) return null;
  const hoy = new Date();
  hoy.setHours(0,0,0,0);
  fechaVenc.setHours(0,0,0,0);
  const diffMs = fechaVenc - hoy;
  return Math.ceil(diffMs / (1000*60*60*24));
}

function abrirClienteDetalle(clienteId) {
  clienteDetalle = obtenerClientePorId(clienteId);
  if (!clienteDetalle) return;

  const elNombre = document.getElementById('cliente-detalle-nombre');
  const elCedula = document.getElementById('cliente-detalle-cedula');
  const elCelular = document.getElementById('cliente-detalle-celular');
  const elTipoPago = document.getElementById('cliente-detalle-tipo-pago');
  const elVenc = document.getElementById('cliente-detalle-vencimiento');
  const elDias = document.getElementById('cliente-detalle-dias-restantes');

  const fotoImg = document.getElementById('cliente-detalle-foto');
  const fallbackIcon = document.getElementById('cliente-detalle-foto-icon');

  if (elNombre) elNombre.textContent = clienteDetalle.nombre || '—';
  if (elCedula) elCedula.textContent = clienteDetalle.cedula || '—';
  if (elCelular) elCelular.textContent = clienteDetalle.celular || '—';
  if (elTipoPago) elTipoPago.textContent = clienteDetalle.tipoPago || '—';
  if (elVenc) elVenc.textContent = clienteDetalle.vencimiento || '—';

  const diasRestantes = obtenerDiasRestantesDesdeVencimiento(clienteDetalle.vencimiento);
  if (elDias) {
    if (diasRestantes === null) elDias.textContent = '—';
    else elDias.textContent = `${diasRestantes} día${diasRestantes === 1 ? '' : 's'}`;
  }

  if (fotoImg) {
    fotoImg.src = clienteDetalle.fotoRostro || '';
    fotoImg.style.display = clienteDetalle.fotoRostro ? 'block' : 'none';
  }
  if (fallbackIcon) {
    fallbackIcon.style.display = clienteDetalle.fotoRostro ? 'none' : 'inline-flex';
  }

  const modal = document.getElementById('cliente-detalle-modal');
  if (modal) modal.style.display = 'flex';
}

function cerrarClienteDetalle() {
  const modal = document.getElementById('cliente-detalle-modal');
  if (modal) modal.style.display = 'none';
  clienteDetalle = null;
}

function abrirClienteActualizarDesdeDetalle() {
  if (!clienteDetalle) return;
  cerrarClienteDetalle();
  abrirEditModal(clienteDetalle.id);
}

function abrirClienteEliminarDesdeDetalle() {
  if (!clienteDetalle) return;
  cerrarClienteDetalle();
  abrirModalEliminar(clienteDetalle.id);
}

function renderizarTablaClientes() {
  const tbody = document.querySelector('#sec-clients table tbody');
  if (!tbody) return;

  const input = document.getElementById('clients-search');
  const q = (input && input.value ? input.value.trim().toLowerCase() : '');

  const clientesFiltrados = q
    ? clientes.filter((c) => {
        const nombre = (c.nombre || '').toLowerCase();
        const cedula = (c.cedula || '').toLowerCase();
        const celular = (c.celular || '').toLowerCase();
        return nombre.includes(q) || cedula.includes(q) || celular.includes(q);
      })
    : clientes;

  tbody.innerHTML = '';

  if (clientesFiltrados.length === 0) {
    const colspan = 7;
    tbody.innerHTML =
      `<tr><td colspan="${colspan}" style="text-align:center; padding:20px; color:#999;">No hay clientes que coincidan</td></tr>`;
    return;
  }

  clientesFiltrados.forEach((cliente) => {
    const row = document.createElement('tr');

    const fotoHTML = cliente.fotoRostro
      ? `<img class="client-photo-thumb" src="${cliente.fotoRostro}" alt="Foto de ${cliente.nombre}">`
      : `<div class="client-photo-cell" style="color:#999; font-weight:700;">—</div>`;

    row.innerHTML = `
      <td>${fotoHTML}</td>
      <td>${cliente.nombre}</td>
      <td>${cliente.cedula}</td>
      <td>${cliente.celular}</td>
      <td><span class="badge-pago">${cliente.tipoPago}</span></td>
      <td>${cliente.vencimiento}</td>
    `;

    row.classList.add('client-row');
    row.style.cursor = 'pointer';
    row.tabIndex = 0;
    row.setAttribute('role', 'button');
    row.setAttribute('aria-label', `Ver detalle de ${cliente.nombre}`);

    row.addEventListener('click', () => abrirClienteDetalle(cliente.id));
    row.addEventListener('keydown', (ev) => {
      if (ev.key === 'Enter' || ev.key === ' ') {
        ev.preventDefault();
        abrirClienteDetalle(cliente.id);
      }
    });

    tbody.appendChild(row);
  });
}


// =====================================================
// UTILIDADES
// =====================================================
function obtenerFechaActual() {
  const hoy = new Date();
  const año = hoy.getFullYear();
  const mes = String(hoy.getMonth() + 1).padStart(2, '0');
  const dia = String(hoy.getDate()).padStart(2, '0');
  return `${año}-${mes}-${dia}`;
}

function leerArchivoComoDataURL(file) {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => resolve(reader.result);
    reader.onerror = () => reject(reader.error);
    reader.readAsDataURL(file);
  });
}

function calcularVencimiento(fechaPago, tipoPago) {
  const fecha = new Date(fechaPago);

  if (tipoPago === 'Diario') {
    fecha.setDate(fecha.getDate() + 1);
  } else if (tipoPago === 'Mensual') {
    fecha.setDate(fecha.getDate() + 30);
  }

  const año = fecha.getFullYear();
  const mes = String(fecha.getMonth() + 1).padStart(2, '0');
  const dia = String(fecha.getDate()).padStart(2, '0');
  return `${año}-${mes}-${dia}`;
}

function mostrarToast(mensaje, tipo = 'info') {
  const toast = document.getElementById('toast');
  if (!toast) return;

  toast.textContent = mensaje;
  toast.className = `toast toast-${tipo}`;
  toast.style.display = 'block';

  setTimeout(() => {
    toast.style.display = 'none';
  }, 3000);
}

// =====================================================
// Exponer funciones globales para onclick inline
// =====================================================
window.simulateLogin = simulateLogin;
window.loginSubmit = loginSubmit;
window.registrarCliente = registrarCliente;
window.abrirEditModal = abrirEditModal;
window.closeEditModal = closeEditModal;
window.saveClientEdit = saveClientEdit;
window.abrirModalEliminar = abrirModalEliminar;
window.cerrarModalEliminar = cerrarModalEliminar;
window.eliminarClienteConfirmado = eliminarClienteConfirmado;
window.abrirClienteDetalle = abrirClienteDetalle;
window.cerrarClienteDetalle = cerrarClienteDetalle;
window.abrirClienteActualizarDesdeDetalle = abrirClienteActualizarDesdeDetalle;
window.abrirClienteEliminarDesdeDetalle = abrirClienteEliminarDesdeDetalle;

// =====================================================
// Arranque
// =====================================================
document.addEventListener('DOMContentLoaded', () => {
  initApp();

  const btnCancelarEliminar = document.getElementById('btnCancelarEliminar');
  const btnConfirmarEliminar = document.getElementById('btnConfirmarEliminar');
  const modalEliminar = document.getElementById('modalEliminar');
  const modalCloseBtn = document.getElementById('modalEliminarClose');

  // Buscador en lista de clientes
  const searchInput = document.getElementById('clients-search');
  if (searchInput) {
    searchInput.addEventListener('input', () => {
      renderizarTablaClientes();
    });
  }


  if (btnCancelarEliminar) btnCancelarEliminar.addEventListener('click', cerrarModalEliminar);
  if (btnConfirmarEliminar) btnConfirmarEliminar.addEventListener('click', eliminarClienteConfirmado);
  if (modalCloseBtn) modalCloseBtn.addEventListener('click', cerrarModalEliminar);

  // Cerrar al hacer clic fuera del contenedor (overlay)
  if (modalEliminar) {
    modalEliminar.addEventListener('click', (e) => {
      if (e.target === modalEliminar) cerrarModalEliminar();
    });
  }
});


